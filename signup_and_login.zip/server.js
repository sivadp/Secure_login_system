const mysql = require("mysql");
const express = require("express");
const app = express();
const bodyparser = require("body-parser");
const encoder = bodyparser.urlencoded({ extended: false });
const nodemailer = require("nodemailer");
const crypto = require("crypto");

app.use("/public", express.static("public"));
app.use(bodyparser.json());

//store details in  mysql module about user and database he has 
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  database: "nodelogin",
  password: "Siva@2000",
});

//connection to the database
connection.connect((err) => {
  if (err) throw err;
  else console.log("connected");
});

//create a transporter object
let transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "duppalapudisiva990@gmail.com",
    pass: "qujillnophnhwsts", //application specific password
  },
});

//open registration page when user browse at /register endpoint
app.get("/register", (req, res) => {
  let message=req.query.message;
  res.sendFile(__dirname + "/public/registration.html",{message:message});
});
//sending js file along with html file of registration page
app.get("/registration.js", (req, res) => {
  res.set("Content-Type", "application/javascript");
  res.sendFile(__dirname + "/public/registration.js");
});

//variables used for querying to database
let otp = "",username,password,email;
//variables determaining key value and algorithm used to encrypt password
const key = "2000";
const algorithm = "aes-256-cbc";

//functions to be invoked when user sends registration form data
app.post("/register", encoder, function (req, res) {
  username = req.body.username;
  password = req.body.password;
  email = req.body.email;
  //checking wheather email already registered or not
  connection.query("select email from accounts where email=?;",[email],(err,results,fields)=>{
    if(results.length>0){
        if(results[0].email==email){
            let message="email already registered"
            res.redirect("/register?message="+message);
        }
    }
  })

  //for generating otp
  const num = "0123456789";
  otp = "";
  for (let i = 0; i < 6; i++) {
    otp += num.charAt(Math.floor(Math.random() * num.length));
  }

  // Define the email options
  let mailOptions = {
    from: "duppalapudisiva990@gmail.com",
    to: email,
    subject: "OTP for verification",
    text: otp,
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
    } else {
      res.sendFile(__dirname+"/public/validation.html");
    }
  });
});

//functions to be involked when user submits an otp 
app.post("/verify-otp", (req, res) => {
  const enteredOtp = req.body.otp;
  const storedOtp = otp;
  if (enteredOtp == storedOtp) {
    let mailOption = {
      from: "duppalapudisiva990@gmail.com",
      to: email,
      subject: "registration successfull",
      text:"you were successfully registered with email :" +email +", user name: " +username +", password: " + password
    };

    transporter.sendMail(mailOption, (error, info) => {
      if (error) {
        console.log(error);
      } else {
        const cipher = crypto.createCipher(algorithm, key);
        let encrypted = cipher.update(password, "utf8", "hex");
        encrypted += cipher.final("hex");
        connection.query(
          "insert into accounts(username,password,email) values(?,?,?);",
          [username, encrypted, email],
          function (err, results, fields) {
            if (err) {
              throw err;
            }
            res.redirect("/login");
          }
        );
      }
    });
  }
});

//for login
app.get("/login", function (req, res) {
  res.sendFile(__dirname + "/public/login.html");
});

//functions to be involked when user submits login form
app.post("/login", encoder, function (req, res) {
  var email = req.body.email;
  var password = req.body.password;
  connection.query(
    "select password,username from accounts where email = ?;",[email],
    function (err, results, fields) {
      if (err) throw err;
      else {
        if (results.length > 0) {
          let k = results[0].password;
          const decipher = crypto.createDecipher(algorithm, key);
          let decrypted = decipher.update(k, "hex", "utf8");
          decrypted += decipher.final("utf8");
          if (decrypted == password) {
            let user=results[0].username;
            res.redirect("/welcome?name="+user);
          } else {
            res.redirect("/invalid");
          }
        } else {
          res.redirect("/invalid");
        }
      }
      res.end();
    }
  );
});
//when login is success
app.get("/welcome", function (req, res) {
  var name=req.query.user;
  res.sendFile(__dirname + "/public/welcome.html",{name: name});
});
//when login is failed
app.get("/invalid", function (req, res) {
  res.sendFile(__dirname + "/public/invalid.html");
});
//setting app port
app.listen(4500);
